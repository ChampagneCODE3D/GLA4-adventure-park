﻿GLA6 dual-version bundle

Includes:
1) GLA6-Jordan-Code-Clean.zip
 - excludes .git, node_modules, .github, postman-evidence

2) GLA6-Jordan-Code-Full-NoPostman.zip
 - excludes .git, node_modules, postman-evidence
 - includes .github workflow files

Use whichever version matches your instructor preference.
